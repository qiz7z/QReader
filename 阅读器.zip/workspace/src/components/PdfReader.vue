<template>
  <div class="pdf-reader">
    <div v-if="loading" class="loading">正在加载 PDF...</div>
    <div v-else-if="error" class="error">{{ error }}</div>
    <div v-else class="pdf-pages">
      <canvas
        v-for="pageNum in totalPages"
        :key="pageNum"
        :ref="(el) => setCanvasRef(pageNum, el)"
        class="pdf-page"
      ></canvas>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch } from 'vue'
import * as pdfjsLib from 'pdfjs-dist'

pdfjsLib.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.mjs`

const props = defineProps<{
  rawFile: ArrayBuffer | null
  theme: 'light' | 'dark' | 'green'
}>()

const loading = ref(true)
const error = ref('')
const totalPages = ref(0)
const canvasRefs = new Map<number, HTMLCanvasElement>()
const renderedPages = new Set<number>()
const renderingPages = new Set<number>()
let pdfDoc: any = null

function setCanvasRef(pageNum: number, el: any) {
  if (el instanceof HTMLCanvasElement) {
    canvasRefs.set(pageNum, el)
    if (pdfDoc) {
      renderPage(pageNum)
    }
  } else {
    canvasRefs.delete(pageNum)
    renderedPages.delete(pageNum)
    renderingPages.delete(pageNum)
  }
}

async function loadPdf() {
  if (!props.rawFile) return
  loading.value = true
  error.value = ''
  renderedPages.clear()
  renderingPages.clear()

    try {
      // 克隆 ArrayBuffer 防止被 Web Worker 占用后报错 "already detached"
      const data = props.rawFile ? props.rawFile.slice(0) : null
      
      // 配置 PDF.js 选项
      // 移除 enableWebGL，回退到 Canvas 2D 渲染，通常对文字锐度更友好
      const pdfOptions: any = {
        data,
        standardFontDataUrl: `https://unpkg.com/pdfjs-dist@${pdfjsLib.version}/standard_fonts/`,
        cMapUrl: `https://unpkg.com/pdfjs-dist@${pdfjsLib.version}/cmaps/`,
        cMapPacked: true
      }

      pdfDoc = await pdfjsLib.getDocument(pdfOptions).promise
      totalPages.value = pdfDoc.numPages

    await renderAllPages()
  } catch (e: any) {
    error.value = 'PDF 加载失败：' + (e.message || '未知错误')
  } finally {
    loading.value = false
  }
}

async function renderPage(pageNum: number) {
  // 防止重复渲染或并发渲染
  if (renderedPages.has(pageNum) || renderingPages.has(pageNum)) return

  const canvas = canvasRefs.get(pageNum)
  if (!canvas || !pdfDoc) return

  renderingPages.add(pageNum)

  try {
    const page = await pdfDoc.getPage(pageNum)
    
    // 1:1 物理像素映射策略 (消除浏览器缩放模糊)
    // 1. 视觉显示保持在 2.0 倍 (200%)，字体更大更易读
    const visualScale = 2.0
    
    const devicePixelRatio = window.devicePixelRatio || 1
    // 2. 渲染倍率严格匹配屏幕物理像素
    // 计算公式：渲染倍率 = 视觉倍率 * 屏幕像素比
    // 例如：普通屏渲染 2 倍，Retina 屏渲染 4 倍
    // 这样 Canvas 的每一个物理像素都精确对应屏幕的一个物理像素，无需浏览器二次缩放
    const scale = visualScale * devicePixelRatio

    const viewport = page.getViewport({ scale })

    // 设置 Canvas 物理尺寸
    canvas.width = Math.ceil(viewport.width)
    canvas.height = Math.ceil(viewport.height)
    
    // 强制设置 Canvas 为块级元素
    canvas.style.display = 'block'

    // 设置 CSS 显示尺寸：逻辑像素大小
    // 确保 1 个 CSS 像素 = devicePixelRatio 个 Canvas 物理像素
    canvas.style.width = `${Math.round(viewport.width / devicePixelRatio)}px`
    canvas.style.height = `${Math.round(viewport.height / devicePixelRatio)}px`

    const ctx = canvas.getContext('2d')
    // 开启平滑处理，优化字体渲染质量
    ctx.imageSmoothingEnabled = true
    ctx.imageSmoothingQuality = 'high'
    if (!ctx) return

    const renderTask = page.render({ canvasContext: ctx, viewport })
    await renderTask.promise
    renderedPages.add(pageNum)
  } catch (e) {
    console.warn(`Failed to render page ${pageNum}:`, e)
  } finally {
    renderingPages.delete(pageNum)
  }
}

async function renderAllPages() {
  for (let i = 1; i <= totalPages.value; i++) {
    await renderPage(i)
  }
}

watch(() => props.rawFile, loadPdf, { immediate: true })

// Removed onMounted to prevent double loading with immediate watch
</script>

<style scoped>
.pdf-reader {
  min-height: 100%;
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.pdf-pages {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
}

.pdf-page {
  /* 移除 max-width: 100%，防止浏览器强制缩放导致高清像素被压缩模糊 */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  background: white;
  /* 移除滤镜，直接展示高清渲染结果 */
}
</style>
