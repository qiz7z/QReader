<template>
  <div
    class="upload-button"
    :class="{ 'is-dragging': isDragging }"
    @dragover.prevent="isDragging = true"
    @dragleave.prevent="isDragging = false"
    @drop.prevent="handleDrop"
    @click="triggerFileInput"
  >
    <span class="upload-icon">+</span>
    <span class="upload-text">导入书籍</span>
    <p class="upload-hint">支持 TXT、EPUB、PDF、MOBI、DOCX、MD</p>
    <input
      ref="fileInput"
      type="file"
      accept=".txt,.md,.epub,.pdf,.mobi,.docx"
      multiple
      hidden
      @change="handleFileSelect"
    />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { FormatParserService } from '@/services/FormatParserService'
import { StorageService } from '@/services/StorageService'
import type { BookRecord } from '@/types'

const fileInput = ref<HTMLInputElement | null>(null)
const isDragging = ref(false)

const emit = defineEmits<{
  (e: 'book-imported', book: BookRecord): void
}>()

const triggerFileInput = () => {
  fileInput.value?.click()
}

const handleFileSelect = (event: Event) => {
  const target = event.target as HTMLInputElement
  if (target.files) {
    importFiles(Array.from(target.files))
  }
}

const handleDrop = (event: DragEvent) => {
  isDragging.value = false
  if (event.dataTransfer?.files) {
    importFiles(Array.from(event.dataTransfer.files))
  }
}

async function importFiles(files: File[]) {
  for (const file of files) {
    const format = FormatParserService.getFormat(file.name)

    if (!FormatParserService.supportsFormat(format)) {
      alert(`不支持的文件格式: ${file.name}`)
      continue
    }

    try {
      const parsedBook = await FormatParserService.parse(file)

      const arrayBuffer = await file.arrayBuffer()
      const bookRecord: BookRecord = {
        id: parsedBook.id,
        title: parsedBook.title,
        author: parsedBook.author,
        format,
        fileSize: file.size,
        cover: parsedBook.cover,
        rawFile: arrayBuffer,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      }

      await StorageService.saveBook(bookRecord)
      await StorageService.saveParsedBook(parsedBook.id, parsedBook)

      emit('book-imported', bookRecord)
    } catch (error) {
      alert(`解析文件失败: ${file.name}\n${(error as Error).message}`)
    }
  }
}
</script>

<style scoped>
.upload-button {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-width: 200px;
  padding: 30px 20px;
  border: 2px dashed #d9d9d9;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.3s;
  background-color: #fafafa;
}

.upload-button:hover {
  border-color: #1890ff;
  background-color: #f0f9ff;
}

.is-dragging {
  border-color: #1890ff;
  background-color: #e6f7ff;
}

.upload-icon {
  font-size: 48px;
  color: #1890ff;
  line-height: 1;
}

.upload-text {
  margin-top: 10px;
  font-size: 16px;
  color: #333;
}

.upload-hint {
  margin: 8px 0 0;
  font-size: 12px;
  color: #999;
}
</style>
