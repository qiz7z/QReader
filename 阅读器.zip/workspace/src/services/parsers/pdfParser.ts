import * as pdfjsLib from 'pdfjs-dist'
import type { ParsedBook, Chapter, TOCEntry } from '@/types'

pdfjsLib.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.mjs`

export async function parsePDF(file: File, arrayBuffer: ArrayBuffer): Promise<ParsedBook> {
  const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer })
  const pdf = await loadingTask.promise

  const content: Chapter[] = []
  const toc: TOCEntry[] = []
  let accumulatedText = ''
  let currentPageNum = 0
  const pagesPerChapter = 1

  const outline = await pdf.getOutline()
  if (outline && outline.length > 0) {
    outline.forEach((item, index) => {
      toc.push({
        title: item.title,
        chapterId: `chapter-${index}`,
        position: index,
      })
    })
  }

  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i)
    const textContent = await page.getTextContent()

    const items = textContent.items as any[]
    const lines = reconstructLines(items)
    const pageText = lines.join('\n')

    const chapterIndex = Math.floor((i - 1) / pagesPerChapter)

    if (currentPageNum !== chapterIndex || content.length === 0) {
      if (accumulatedText.trim()) {
        content.push({
          id: `chapter-${currentPageNum}`,
          title: toc[currentPageNum]?.title || `第 ${currentPageNum + 1} 页`,
          content: formatTextToHtml(accumulatedText),
        })
      }
      currentPageNum = chapterIndex
      accumulatedText = ''
    }

    accumulatedText += pageText + '\n\n'
  }

  if (accumulatedText.trim()) {
    content.push({
      id: `chapter-${currentPageNum}`,
      title: toc[currentPageNum]?.title || `第 ${currentPageNum + 1} 页`,
      content: formatTextToHtml(accumulatedText),
    })
  }

  if (content.length === 0) {
    content.push({
      id: 'chapter-0',
      title: '正文',
      content: '<p>无法提取文本内容</p>',
    })
    toc.push({
      title: '正文',
      chapterId: 'chapter-0',
      position: 0,
    })
  }

  return {
    id: crypto.randomUUID(),
    title: file.name.replace(/\.[^.]+$/, ''),
    author: '',
    cover: null,
    content,
    toc: toc.length > 0 ? toc : [{ title: '正文', chapterId: 'chapter-0', position: 0 }],
    metadata: {},
  }
}

function reconstructLines(items: any[]): string[] {
  if (items.length === 0) return []

  const lineMap = new Map<number, string[]>()

  for (const item of items) {
    if (!item.str || !item.str.trim()) continue

    const y = Math.round(item.transform[5])
    if (!lineMap.has(y)) {
      lineMap.set(y, [])
    }
    lineMap.get(y)!.push(item.str)
  }

  const sortedYs = Array.from(lineMap.keys()).sort((a, b) => b - a)
  const lines: string[] = []

  for (const y of sortedYs) {
    const parts = lineMap.get(y)!
    const line = parts.join('').trim()
    if (line) {
      lines.push(line)
    }
  }

  return lines
}

function formatTextToHtml(text: string): string {
  const paragraphs = text.split(/\n\s*\n/)
  return paragraphs
    .filter((p) => p.trim())
    .map((p) => {
      const lines = p.trim().split(/\n/)
      return `<p>${escapeHtml(lines.join(' '))}</p>`
    })
    .join('')
}

function escapeHtml(text: string): string {
  const div = document.createElement('div')
  div.textContent = text
  return div.innerHTML
}
