import ePub from 'epubjs'
import type { ParsedBook, Chapter } from '@/types'

export async function parseEPUB(file: File, arrayBuffer: ArrayBuffer): Promise<ParsedBook> {
  const book = ePub(arrayBuffer)
  await book.ready

  const metadata = await book.loaded.metadata
  const title = (metadata as any).title || file.name.replace(/\.[^.]+$/, '')
  const author = (metadata as any).creator || ''

  const nav = await book.loaded.navigation
  const toc = (nav as any).toc.map((item: any, index: number) => ({
    title: item.label,
    chapterId: `chapter-${index}`,
    position: index,
  }))

  const spine = (book as any).spine
  const spineLength = spine.length
  const content: Chapter[] = []

  // 缓存已解析的图片资源
  const imageCache = new Map<string, string>()

  for (let i = 0; i < spineLength; i++) {
    const item = spine.get(i)
    const html = await loadChapterContent(book, item, imageCache)
    content.push({
      id: `chapter-${i}`,
      title: toc[i]?.title || `第 ${i + 1} 节`,
      content: html,
    })
  }

  // 提取封面：从 ZIP 中直接读取，避免使用临时 blob URL（在 book.destroy() 后失效）
  let cover: ArrayBuffer | null = null
  const archive = (book as any).archive
  
  if (archive) {
    // 方式1: 尝试通过 epubjs 的 cover 属性获取封面路径
    const coverUrl = (book as any).cover
    if (coverUrl) {
      try {
        // 优先使用 archive.readFile 直接从 ZIP 读取
        cover = await archive.readFile(coverUrl) as ArrayBuffer
      } catch {
        // 方式2: 如果 coverUrl 是 blob URL，尝试 fetch（仅在 book.destroy() 前有效）
        try {
          if (coverUrl.startsWith('blob:')) {
            const response = await fetch(coverUrl)
            cover = await response.arrayBuffer()
          }
        } catch {
          // 忽略
        }
      }
    }
    
    // 方式3: 如果上述都失败，尝试从 manifest 中查找封面图片
    if (!cover && archive.zip) {
      try {
        const manifest = (book as any).package?.manifest
        if (manifest) {
          // 查找标记为 cover-image 或名称包含 cover 的文件
          const coverId = (book as any).package?.metadata?.cover
          let coverHref = ''
          
          if (coverId && manifest[coverId]) {
            coverHref = manifest[coverId].href
          } else {
            // 遍历 manifest 查找封面
            for (const [id, item] of Object.entries(manifest)) {
              const entry = item as { href?: string; properties?: string; mediaType?: string }
              if (entry.properties?.includes('cover-image') || 
                  id.toLowerCase().includes('cover') || 
                  (entry.href && entry.href.toLowerCase().includes('cover'))) {
                coverHref = entry.href || ''
                break
              }
            }
          }
          
          if (coverHref) {
            try {
              cover = await archive.readFile(coverHref) as ArrayBuffer
            } catch {
              // 尝试从 ZIP 直接读取
              const files = archive.zip.file(/cover/i)
              if (files.length > 0) {
                const coverBlob = await files[0].async('blob')
                cover = await coverBlob.arrayBuffer()
              }
            }
          }
        }
      } catch {
        // 忽略
      }
    }
    
    // 方式4: 最后的兜底方案 - 查找 ZIP 中第一个较大的图片作为封面
    if (!cover && archive.zip) {
      try {
        const imageFiles = archive.zip.file(/\.(jpg|jpeg|png|gif)$/i)
          .filter((f: any) => !f.name.includes('__MACOSX') && !f.name.includes('/'))
          .sort((a: any, b: any) => b._data.uncompressedSize - a._data.uncompressedSize)
        
        if (imageFiles.length > 0) {
          const firstImg = await imageFiles[0].async('blob')
          cover = await firstImg.arrayBuffer()
        }
      } catch {
        // 忽略
      }
    }
  }

  await book.destroy()

  return {
    id: crypto.randomUUID(),
    title,
    author,
    cover,
    content,
    toc,
    metadata: {
      publisher: (metadata as any).publisher || '',
      language: (metadata as any).language || '',
      description: (metadata as any).description || '',
    },
  }
}

async function loadChapterContent(book: any, item: any, imageCache: Map<string, string>): Promise<string> {
  const contents = await book.load(item.href)
  const serializer = new XMLSerializer()
  let html = serializer.serializeToString(contents as Node)

  // 提取并替换图片路径
  const parser = new DOMParser()
  const doc = parser.parseFromString(html, 'text/html')
  const images = doc.querySelectorAll('img')

  for (const img of Array.from(images)) {
    const src = img.getAttribute('src')
    if (!src) continue

    // 如果已经缓存过该图片，直接使用
    if (imageCache.has(src)) {
      img.setAttribute('src', imageCache.get(src)!)
      continue
    }

    // 解析相对路径为 epub 内部的绝对路径
    let internalPath = src
    try {
      // epubjs 提供 resolvePath 方法将相对路径转为内部路径
      internalPath = book.path.resolve(src)
      if (!internalPath && book.archive?.resolvePath) {
        internalPath = book.archive.resolvePath(src)
      }
      // 如果 resolve 失败，尝试拼接当前章节目录
      if (!internalPath) {
        const chapterDir = item.href.substring(0, item.href.lastIndexOf('/') + 1)
        internalPath = chapterDir + src
      }
    } catch {
      const chapterDir = item.href.substring(0, item.href.lastIndexOf('/') + 1)
      internalPath = chapterDir + src
    }

    try {
      // 解析相对路径为 epub 内部的绝对路径
      let internalPath = src
      try {
        internalPath = book.path.resolve(src)
      } catch {
        const chapterDir = item.href.substring(0, item.href.lastIndexOf('/') + 1)
        internalPath = chapterDir + src
      }

      // 清理路径：去除可能存在的引导 /，因为 zip 文件通常以相对路径存储
      let normalizedPath = internalPath
      if (normalizedPath.startsWith('/')) {
        normalizedPath = normalizedPath.substring(1)
      }

      // 使用 epubjs 内部的 JSZip 实例提取图片
      let zipEntry = book.archive.zip.file(normalizedPath)
      
      // 如果精确匹配失败，尝试模糊匹配（处理一些 epub 路径不规范的情况）
      if (!zipEntry) {
        const files = book.archive.zip.file(/\.jpeg$|\.jpg$|\.png$|\.gif$/i)
        const targetSuffix = internalPath.split('/').pop()
        const match = files.find(f => f.name.endsWith(targetSuffix || ''))
        if (match) {
          zipEntry = match
          normalizedPath = match.name
        }
      }

      if (zipEntry) {
        const blob = await zipEntry.async('blob')
        const base64 = await blobToBase64(blob)
        imageCache.set(src, base64)
        img.setAttribute('src', base64)
      } else {
        console.warn('Image not found in zip:', internalPath, 'normalized:', normalizedPath)
      }
    } catch (e) {
      console.warn('Failed to load image:', src, e)
    }
  }

  return doc.body.innerHTML
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onloadend = () => resolve(reader.result as string)
    reader.onerror = reject
    reader.readAsDataURL(blob)
  })
}
