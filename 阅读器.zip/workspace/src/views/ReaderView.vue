<template>
  <div class="reader-view" :class="themeClass">
    <!-- 顶部工具栏 -->
    <header class="reader-toolbar">
      <span>{{ book?.title || '加载中...' }}</span>
    </header>

    <div class="reader-body">
      <!-- 左侧目录 -->
      <aside class="reader-sidebar" :class="{ collapsed: !showTocPanel }" :style="{ width: showTocPanel ? sidebarWidth + 'px' : '60px' }">
        <template v-if="showTocPanel">
          <div class="sidebar-header">
            <h3>目录</h3>
            <button @click="showTocPanel = false" title="收起" class="collapse-btn">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="15 18 9 12 15 6"></polyline>
              </svg>
            </button>
          </div>
          <div class="sidebar-content">
            <div v-if="book?.content?.length" v-for="(ch, idx) in book.content" :key="ch.id || idx" class="toc-item" :class="{ active: currentChapter === idx }" @click="currentChapter = idx">
              <span class="toc-icon">#</span>
              <span class="toc-title">{{ ch.title || `第 ${idx + 1} 章` }}</span>
            </div>
            <div v-else class="empty-text">暂无目录</div>
          </div>
        </template>

        <div v-else class="sidebar-collapsed" @click="showTocPanel = true" title="展开目录">
          <div class="toc-icon-btn">
            <svg class="collapsed-icon-svg" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
            </svg>
            <span class="badge-dot"></span>
          </div>
          <div class="collapsed-label">目录</div>
        </div>
      </aside>

      <!-- 拖拽条 -->
      <div v-if="showTocPanel" class="resize-bar" @mousedown="startResize"></div>

      <!-- 主阅读区 -->
      <main class="reader-main" ref="mainRef">
        <PdfReader v-if="book && bookFormat === 'pdf'" :raw-file="rawFile" :theme="readerStore.theme" />
        <div v-else-if="book" class="reader-content" v-html="currentContent" :style="contentStyle" />
        <div v-else class="loading">加载中...</div>

        <!-- 章节导航 -->
        <div v-if="!isFullscreen && bookFormat !== 'pdf'" class="reader-nav-cr">
          <div class="nav-buttons">
            <button class="nav-btn" @click="prevPage" :disabled="currentChapter <= 0">上一章</button>
            <button class="nav-btn" @click="nextPage" :disabled="currentChapter >= (book?.content?.length || 1) - 1">下一章</button>
          </div>
          <div class="chapter-indicator" v-if="!isJumping" @click="startJump">
            {{ currentChapter + 1 }} / {{ book?.content?.length || 0 }}
          </div>
          <div v-else class="chapter-jump-input-wrapper">
            <input
              type="number"
              v-model.number="jumpInput"
              @keyup.enter="confirmJump"
              @blur="confirmJump"
              ref="jumpInputRef"
              class="chapter-input"
              min="1"
              :max="book?.content?.length || 1"
            />
          </div>
        </div>

        <!-- 悬浮全屏按钮 -->
        <button v-if="!isFullscreen && bookFormat !== 'pdf'" class="fullscreen-btn-float" @click="toggleFullscreen" title="全屏阅读">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M15 3h6v6"></path><path d="M9 21H3v-6"></path>
            <path d="M21 3l-7 7"></path><path d="M3 21l7-7"></path>
          </svg>
        </button>
      </main>

        <!-- 右侧工具栏 -->
      <aside class="reader-right">
        <div class="right-tools">
          <button class="tool-btn" @click="toggleRight('shelf')" :class="{ active: rightPanel === 'shelf' }" title="书架">📚</button>
          <button class="tool-btn" @click="toggleRight('settings')" :class="{ active: rightPanel === 'settings' }" title="设置">⚙</button>
        </div>

        <transition name="panel-slide">
          <div v-if="rightPanel" class="right-panel" :class="rightPanel">
            <div class="right-panel-hd">
              <span>{{ rightPanel === 'shelf' ? '书架' : '阅读设置' }}</span>
              <button class="close-btn" @click="rightPanel = ''">✕</button>
            </div>
            <div class="right-panel-bd">
              <!-- 书架 -->
              <div v-if="rightPanel === 'shelf'" class="shelf-panel">
                <div v-if="shelfList.length" class="shelf-grid">
                  <div v-for="b in shelfList" :key="b.id" class="shelf-card" @click="openBook(b.id)">
                    <div class="shelf-cover-img">
                      <img :src="coverUrl(b.id, b.cover, b.title)" alt="" />
                    </div>
                    <div class="shelf-info">
                      <div class="shelf-name">{{ b.title }}</div>
                    </div>
                  </div>
                </div>
                <div v-else class="empty-placeholder">
                  <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
                  <p>暂无书籍</p>
                </div>
              </div>

              <!-- 设置 -->
              <div v-if="rightPanel === 'settings'" class="settings-panel">
                <div class="setting-group">
                  <label class="group-label">字体大小</label>
                  <div class="size-control">
                    <button @click="readerStore.setFontSize(Math.max(1, readerStore.fontSize - 1))">−</button>
                    <div class="size-dots">
                      <span v-for="i in 5" :key="i" class="dot" :class="{ active: i <= readerStore.fontSize }"></span>
                    </div>
                    <button @click="readerStore.setFontSize(Math.min(5, readerStore.fontSize + 1))">+</button>
                  </div>
                </div>
                <div class="setting-group">
                  <label class="group-label">字体粗细</label>
                  <div class="weight-grid">
                    <button v-for="w in weights" :key="w.v" class="weight-btn" :class="{ active: readerStore.fontWeight === w.v }" @click="readerStore.setFontWeight(w.v)">{{ w.l }}</button>
                  </div>
                </div>
                <div class="setting-group">
                  <label class="group-label">阅读主题</label>
                  <div class="theme-grid">
                    <button v-for="t in themes" :key="t.v" class="theme-btn" :class="{ active: readerStore.theme === t.v }" @click="readerStore.setTheme(t.v)">{{ t.l }}</button>
                  </div>
                </div>
                <div class="setting-group">
                  <label class="group-label">字体风格</label>
                  <div class="font-family-grid">
                    <button v-for="f in fonts" :key="f.v" class="font-btn" :class="{ active: readerStore.fontFamily === f.v }" @click="readerStore.setFontFamily(f.v)" :style="{ fontFamily: f.css }">{{ f.l }}</button>
                  </div>
                </div>
                <div class="setting-group data-management">
                  <label class="group-label">数据管理</label>
                  <button class="danger-btn" @click="handleClearAllData">清除所有数据</button>
                </div>
              </div>
            </div>
          </div>
        </transition>
      </aside>
    </div>

    <!-- 全屏导航 -->
    <div v-if="isFullscreen && bookFormat !== 'pdf'" class="fullnav">
      <button class="nav-btn" @click="prevPage" :disabled="currentChapter <= 0">上一章</button>
      
      <div class="full-chapter-wrapper">
        <div class="chapter-indicator full-screen" v-if="!isJumping" @click="startJump">
          {{ currentChapter + 1 }} / {{ book?.content?.length || 0 }}
        </div>
        <div v-else class="chapter-jump-input-wrapper full-screen">
          <input
            type="number"
            v-model.number="jumpInput"
            @keyup.enter="confirmJump"
            @blur="confirmJump"
            class="chapter-input full-screen"
            min="1"
            :max="book?.content?.length || 1"
          />
        </div>
      </div>

      <button class="nav-btn" @click="nextPage" :disabled="currentChapter >= (book?.content?.length || 1) - 1">下一章</button>
    </div>

    <div v-if="isFullscreen && showFullToc && book" class="full-toc-overlay" @click="showFullToc = false">
      <div class="full-toc" @click.stop>
        <div class="full-toc-hd"><span>目录</span><button @click="showFullToc = false">关闭</button></div>
        <div class="full-toc-bd">
          <div v-for="(ch, idx) in book.content" :key="ch.id || idx" class="full-toc-item" :class="{ active: currentChapter === idx }" @click="currentChapter = idx; showFullToc = false">
            <span class="toc-icon">#</span>{{ ch.title || `第 ${idx + 1} 章` }}
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted, onBeforeUnmount } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { StorageService } from '@/services/StorageService'
import { useReaderStore } from '@/stores/reader'
import PdfReader from '@/components/PdfReader.vue'
import type { ParsedBook } from '@/types'

const route = useRoute()
const router = useRouter()
const readerStore = useReaderStore()
const bookId = computed(() => route.params.id as string)

const book = ref<ParsedBook | null>(null)
const rawFile = ref<ArrayBuffer | null>(null)
const bookFormat = ref('')
const currentChapter = ref(0)
const isFullscreen = ref(false)
const mainRef = ref<HTMLElement | null>(null)

const showTocPanel = ref(true)
const sidebarWidth = ref(200)
const minW = 120
const maxW = 400

const rightPanel = ref('')
const shelfList = ref<Array<{ id: string; title: string; cover: ArrayBuffer | null }>>([])
const showFullToc = ref(false)
const jumpInput = ref('')
const isJumping = ref(false)
const jumpInputRef = ref<HTMLInputElement | null>(null)

const weights = [
  { l: '细-', v: 1 }, { l: '细', v: 2 }, { l: '细+', v: 3 },
  { l: '默认', v: 4 },
  { l: '粗-', v: 5 }, { l: '粗', v: 6 }, { l: '粗+', v: 7 },
]
const themes = [
  { l: '白天', v: 'light' as const },
  { l: '夜间', v: 'dark' as const },
  { l: '护眼', v: 'green' as const },
]
const fonts = [
  { l: '默认', v: 0, css: 'system-ui, -apple-system, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif' },
  { l: '宋体', v: 1, css: '"Songti SC", "SimSun", "STSong", Georgia, serif' },
  { l: '楷体', v: 2, css: '"Kaiti SC", "STKaiti", "KaiTi", "AR PL UKai CN", serif' },
  { l: '黑体', v: 3, css: '"HeiTi SC", "SimHei", sans-serif' },
  { l: '等宽', v: 4, css: 'Menlo, Monaco, Consolas, "Courier New", monospace' },
  { l: '仿宋', v: 5, css: '"FangSong", "STFangsong", "AR PL FangSong", serif' },
]

const themeClass = computed(() => `theme-${readerStore.theme}`)
const currentContent = computed(() => (book.value?.content?.[currentChapter.value]?.content || ''))

const contentStyle = computed(() => ({
  fontSize: `${14 + readerStore.fontSize * 2}px`,
  fontWeight: `${200 + readerStore.fontWeight * 100}`,
  fontFamily: fonts[readerStore.fontFamily]?.css || fonts[0].css,
}))

async function loadBook(id: string) {
  book.value = null
  currentChapter.value = 0
  const rec = await StorageService.getBook(id)
  if (rec) { bookFormat.value = rec.format; rawFile.value = rec.rawFile }
  const loaded = await StorageService.getParsedBook(id)
  if (loaded) book.value = loaded
}

// 监听路由参数变化，支持在书架中切换书籍
watch(bookId, (newId) => { if (newId) loadBook(newId) })

let resizing = false
function startResize(e: MouseEvent) {
  if (!showTocPanel.value) return
  resizing = true
  document.body.style.cursor = 'col-resize'
  document.body.style.userSelect = 'none'
  function move(ev: MouseEvent) {
    if (!resizing) return
    const w = ev.clientX
    if (w >= minW && w <= maxW) sidebarWidth.value = w
  }
  function up() {
    if (!resizing) return
    resizing = false
    document.body.style.cursor = ''
    document.body.style.userSelect = ''
    try { localStorage.setItem('reader-sidebar-width', String(sidebarWidth.value)) } catch {}
    window.removeEventListener('mousemove', move)
    window.removeEventListener('mouseup', up)
  }
  window.addEventListener('mousemove', move)
  window.addEventListener('mouseup', up)
}

function scrollToChapterStart() {
  if (mainRef.value) mainRef.value.scrollTop = 0
}
function prevPage() {
  if (currentChapter.value > 0) { currentChapter.value--; scrollToChapterStart() }
}
function nextPage() {
  if (book.value && currentChapter.value < book.value.content.length - 1) { currentChapter.value++; scrollToChapterStart() }
}

async function loadShelf() {
  try {
    const all = await StorageService.getAllBooks()
    shelfList.value = all.map(b => ({ id: b.id, title: b.title, cover: b.cover }))
  } catch {
    shelfList.value = []
  }
}
async function openBook(id: string) {
  if (id === bookId.value) return
  rightPanel.value = ''
  await loadBook(id)
  router.push(`/book/${id}`)
}
function toggleRight(p: 'shelf' | 'settings') {
  rightPanel.value = rightPanel.value === p ? '' : p
}

// 生成文件名封面
function generateCover(title: string): ArrayBuffer {
  const canvas = document.createElement('canvas')
  const w = 300, h = 420
  canvas.width = w
  canvas.height = h
  const ctx = canvas.getContext('2d')!
  
  // 基于标题生成稳定的渐变色
  let hash = 0
  for (let i = 0; i < title.length; i++) {
    hash = title.charCodeAt(i) + ((hash << 5) - hash)
  }
  const h1 = Math.abs(hash) % 360
  const h2 = (h1 + 40) % 360
  
  const gradient = ctx.createLinearGradient(0, 0, w, h)
  gradient.addColorStop(0, `hsl(${h1}, 60%, 45%)`)
  gradient.addColorStop(1, `hsl(${h2}, 50%, 35%)`)
  ctx.fillStyle = gradient
  ctx.fillRect(0, 0, w, h)
  
  // 绘制装饰圆
  ctx.globalAlpha = 0.08
  ctx.fillStyle = '#fff'
  ctx.beginPath()
  ctx.arc(w * 0.8, h * 0.2, 120, 0, Math.PI * 2)
  ctx.fill()
  ctx.beginPath()
  ctx.arc(w * 0.15, h * 0.85, 80, 0, Math.PI * 2)
  ctx.fill()
  ctx.globalAlpha = 1
  
  // 绘制书名文字
  ctx.fillStyle = '#fff'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  
  const maxChars = 12
  const displayTitle = title.length > maxChars ? title.slice(0, maxChars) + '...' : title
  
  // 自动调整字号
  let fontSize = 28
  ctx.font = `bold ${fontSize}px sans-serif`
  while (ctx.measureText(displayTitle).width > w - 40 && fontSize > 16) {
    fontSize -= 2
    ctx.font = `bold ${fontSize}px sans-serif`
  }
  
  // 多行显示
  const chars = displayTitle.split('')
  const lines: string[] = []
  let line = ''
  for (const ch of chars) {
    const test = line + ch
    if (ctx.measureText(test).width > w - 40) {
      lines.push(line)
      line = ch
    } else {
      line = test
    }
  }
  if (line) lines.push(line)
  
  const lineHeight = fontSize * 1.4
  const startY = h / 2 - (lines.length - 1) * lineHeight / 2
  
  ctx.shadowColor = 'rgba(0,0,0,0.3)'
  ctx.shadowBlur = 6
  ctx.shadowOffsetY = 2
  
  lines.forEach((l, i) => {
    ctx.fillText(l, w / 2, startY + i * lineHeight)
  })
  
  const dataUrl = canvas.toDataURL('image/png')
  const base64 = dataUrl.split(',')[1]
  const binaryString = atob(base64)
  const bytes = new Uint8Array(binaryString.length)
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i)
  }
  return bytes.buffer as ArrayBuffer
}

// 将 ArrayBuffer 封面转为 blob URL，无封面时动态生成文件名封面
const coverUrlCache = new Map<string, string>()
function coverUrl(bookId: string, data: ArrayBuffer | null, title: string): string {
  let url = coverUrlCache.get(bookId)
  if (!url) {
    let blob: Blob
    if (data) {
      blob = new Blob([data])
    } else {
      const canvas = document.createElement('canvas')
      const w = 300, h = 420
      canvas.width = w
      canvas.height = h
      const ctx = canvas.getContext('2d')!
      
      let hash = 0
      for (let i = 0; i < title.length; i++) {
        hash = title.charCodeAt(i) + ((hash << 5) - hash)
      }
      const h1 = Math.abs(hash) % 360
      const h2 = (h1 + 40) % 360
      
      const gradient = ctx.createLinearGradient(0, 0, w, h)
      gradient.addColorStop(0, `hsl(${h1}, 60%, 45%)`)
      gradient.addColorStop(1, `hsl(${h2}, 50%, 35%)`)
      ctx.fillStyle = gradient
      ctx.fillRect(0, 0, w, h)
      
      ctx.globalAlpha = 0.08
      ctx.fillStyle = '#fff'
      ctx.beginPath()
      ctx.arc(w * 0.8, h * 0.2, 120, 0, Math.PI * 2)
      ctx.fill()
      ctx.beginPath()
      ctx.arc(w * 0.15, h * 0.85, 80, 0, Math.PI * 2)
      ctx.fill()
      ctx.globalAlpha = 1
      
      ctx.fillStyle = '#fff'
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      
      const maxChars = 12
      const displayTitle = title.length > maxChars ? title.slice(0, maxChars) + '...' : title
      
      let fontSize = 28
      ctx.font = `bold ${fontSize}px sans-serif`
      while (ctx.measureText(displayTitle).width > w - 40 && fontSize > 16) {
        fontSize -= 2
        ctx.font = `bold ${fontSize}px sans-serif`
      }
      
      const chars = displayTitle.split('')
      const lines: string[] = []
      let line = ''
      for (const ch of chars) {
        const test = line + ch
        if (ctx.measureText(test).width > w - 40) {
          lines.push(line)
          line = ch
        } else {
          line = test
        }
      }
      if (line) lines.push(line)
      
      const lineHeight = fontSize * 1.4
      const startY = h / 2 - (lines.length - 1) * lineHeight / 2
      
      ctx.shadowColor = 'rgba(0,0,0,0.3)'
      ctx.shadowBlur = 6
      ctx.shadowOffsetY = 2
      
      lines.forEach((l, i) => {
        ctx.fillText(l, w / 2, startY + i * lineHeight)
      })
      
      blob = canvasToBlob(canvas)
    }
    url = URL.createObjectURL(blob)
    coverUrlCache.set(bookId, url)
  }
  return url
}

function canvasToBlob(canvas: HTMLCanvasElement): Blob {
  const dataUrl = canvas.toDataURL('image/png')
  const base64 = dataUrl.split(',')[1]
  const binaryString = atob(base64)
  const bytes = new Uint8Array(binaryString.length)
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i)
  }
  return new Blob([bytes], { type: 'image/png' })
}

function startJump() {
  jumpInput.value = currentChapter.value + 1
  isJumping.value = true
  setTimeout(() => {
    jumpInputRef.value?.focus()
    jumpInputRef.value?.select()
  }, 50)
}

function confirmJump() {
  const max = book.value?.content?.length || 1
  const target = parseInt(jumpInput.value, 10)
  if (!isNaN(target) && target >= 1 && target <= max) {
    currentChapter.value = target - 1
    scrollToChapterStart()
  }
  isJumping.value = false
}

// 数据管理
async function handleClearAllData() {
  if (confirm('确定要清除所有数据吗？此操作不可撤销。')) {
    await StorageService.deleteAllData()
    alert('所有数据已清除')
    window.location.reload()
  }
}

function toggleFullscreen() {
  if (!document.fullscreenElement) { document.documentElement.requestFullscreen().catch(() => {}) ; isFullscreen.value = true }
  else { document.exitFullscreen(); isFullscreen.value = false }
}
function onFs() { isFullscreen.value = !!document.fullscreenElement }

onMounted(async () => {
  try { const s = localStorage.getItem('reader-sidebar-width'); if (s) { const n = parseInt(s, 10); if (!Number.isNaN(n)) sidebarWidth.value = Math.max(minW, Math.min(maxW, n)) } } catch {}
  await loadShelf()
  await loadBook(bookId.value)
  document.addEventListener('fullscreenchange', onFs)
})
onBeforeUnmount(() => { document.removeEventListener('fullscreenchange', onFs) })
</script>

<style scoped>
.reader-view {
  height: 100vh; display: flex; flex-direction: column; overflow: hidden;
}
.reader-toolbar {
  height: 44px; padding: 0 16px; background: rgba(255,255,255,0.85); backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(0,0,0,0.06); display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; font-size: 15px; font-weight: 500; z-index: 20; color: #333;
}
.theme-dark .reader-toolbar { background: rgba(26,26,26,0.85); border-color: rgba(255,255,255,0.06); color: #e0e0e0; }

/* 布局容器 */
.reader-body { flex: 1; display: flex; overflow: hidden; position: relative; }

/* 左侧目录 */
.reader-sidebar {
  background: #fff; border-right: 1px solid #eee;
  display: flex; flex-direction: column; flex-shrink: 0; transition: width 0.2s;
}
.reader-sidebar.collapsed { border-right: none; }
.sidebar-header { padding: 8px 10px; border-bottom: 1px solid #eee; display: flex; align-items: center; justify-content: space-between; font-size: 14px; flex-shrink: 0; }
.collapse-btn {
  display: flex; align-items: center; justify-content: center;
  width: 28px; height: 28px;
  border: none; border-radius: 6px;
  background: transparent;
  color: #888;
  cursor: pointer;
  transition: all 0.2s;
}
.collapse-btn:hover { background: rgba(24,144,255,0.1); color: #1890ff; transform: translateX(-2px); }
.sidebar-content { flex: 1; overflow-y: auto; padding: 4px 0; }
.toc-item { display: flex; align-items: center; gap: 6px; padding: 8px 10px; cursor: pointer; font-size: 15px; }
.toc-item .toc-icon { font-size: 13px; color: #999; flex-shrink: 0; }
.toc-item.active { background: rgba(24,144,255,0.1); border-left: 3px solid #1890ff; font-weight: 600; }

/* 收起状态：居中醒目 */
.sidebar-collapsed {
  flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-start;
  cursor: pointer; user-select: none; padding: 15vh 4px 12px; text-align: center;
}
.toc-icon-btn {
  width: 44px; height: 44px;
  background: #fff;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 4px 12px rgba(0,0,0,0.12);
  transition: all 0.25s ease;
  margin-bottom: 10px;
  position: relative;
  border: 1px solid rgba(0,0,0,0.04);
}
.badge-dot {
  position: absolute; top: 4px; right: 4px;
  width: 8px; height: 8px;
  background: #1890ff;
  border-radius: 50%;
  border: 2px solid #fff;
  opacity: 0;
  transform: scale(0);
  transition: all 0.2s;
}
.toc-icon-btn:hover {
  background: #1890ff;
  box-shadow: 0 6px 16px rgba(24,144,255,0.25);
  transform: translateY(-3px) scale(1.05);
  border-color: #1890ff;
}
.toc-icon-btn:hover .badge-dot { opacity: 0; transform: scale(0); }
.toc-icon-btn .collapsed-icon-svg { color: #666; transition: color 0.2s; }
.toc-icon-btn:hover .collapsed-icon-svg { color: #fff; }
.collapsed-label { font-size: 13px; color: #666; letter-spacing: 2px; font-weight: 500; transition: color 0.2s; }
.sidebar-collapsed:hover .collapsed-label { color: #1890ff; }

/* 拖拽条 */
.resize-bar { width: 6px; cursor: col-resize; background: transparent; flex-shrink: 0; }
.resize-bar:hover { background: rgba(0,0,0,0.06); }

/* 主阅读区 */
.reader-main { flex: 1; overflow-y: auto; position: relative; min-width: 0; background: #fff; transition: background 0.3s, color 0.3s; }
.reader-content { max-width: 720px; margin: 0 auto; padding: 16px 20px 100px; }
.loading { text-align: center; padding: 40px; color: #999; }

/* 右下角章节按钮 */
.reader-nav-cr { position: fixed; right: 76px; bottom: 20px; display: flex; flex-direction: column; align-items: center; gap: 8px; z-index: 30; }
.nav-buttons { display: flex; gap: 8px; }
.nav-btn { padding: 6px 14px; border-radius: 20px; border: 1px solid rgba(0,0,0,0.08); background: rgba(255,255,255,0.85); backdrop-filter: blur(4px); color: #333; cursor: pointer; font-size: 13px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); transition: all 0.2s; display: flex; align-items: center; gap: 4px; }
.nav-btn:hover:not(:disabled) { background: rgba(24,144,255,0.1); border-color: #1890ff; color: #1890ff; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(24,144,255,0.15); }
.nav-btn:active:not(:disabled) { transform: translateY(0); }
.nav-btn:disabled { opacity: 0.4; cursor: not-allowed; background: rgba(240,240,240,0.5); }
.chapter-indicator { background: rgba(255,255,255,0.9); padding: 4px 14px; border-radius: 14px; font-family: 'Georgia', 'Times New Roman', serif; font-size: 14px; font-weight: 500; color: #555; box-shadow: 0 2px 6px rgba(0,0,0,0.1); border: 1px solid rgba(0,0,0,0.04); letter-spacing: 1px; cursor: pointer; transition: all 0.2s; }
.chapter-indicator:hover { background: rgba(24,144,255,0.05); border-color: rgba(24,144,255,0.3); color: #1890ff; }

.chapter-jump-input-wrapper { position: relative; width: 80px; }
.chapter-input { width: 100%; background: #fff; border: 1px solid #1890ff; border-radius: 14px; padding: 4px 8px; font-size: 14px; font-family: 'Georgia', serif; color: #333; text-align: center; outline: none; box-shadow: 0 2px 6px rgba(24,144,255,0.2); }
.chapter-input::-webkit-inner-spin-button, .chapter-input::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }

.fullscreen-btn-float {
  position: fixed;
  bottom: 12px;
  right: 6px;
  width: 52px;
  height: 52px;
  border-radius: 8px;
  background: rgba(255,255,255,0.85);
  backdrop-filter: blur(4px);
  border: 1px solid rgba(0,0,0,0.08);
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 50;
  transition: all 0.2s;
  color: #555;
}
.fullscreen-btn-float:hover {
  background: rgba(24,144,255,0.1);
  border-color: #1890ff;
  color: #1890ff;
  transform: translateY(-1px);
}
.theme-dark .fullscreen-btn-float {
  background: rgba(45,45,45,0.85);
  border-color: rgba(255,255,255,0.1);
  color: #e0e0e0;
}
.fullscreen-btn { padding: 6px; display: flex; align-items: center; justify-content: center; }
.fullscreen-btn:hover { background: rgba(24,144,255,0.1); border-color: #1890ff; }

/* 右侧区域：固定宽度定位容器 */
.reader-right {
  position: relative;
  width: 64px;
  height: 100%;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: #fff;
  border-left: 1px solid #eee;
}
.right-tools { 
  display: flex; 
  flex-direction: column; 
  gap: 6px; 
  align-items: center; 
  padding-top: 15vh; 
  width: 100%;
  height: 100%;
}
.tool-divider { width: 24px; height: 1px; background: rgba(0,0,0,0.1); margin: 4px 0; }
.theme-dark .tool-divider { background: rgba(255,255,255,0.1); }
.tool-icon { width: 20px; height: 20px; }
.tool-btn { width: 52px; height: 52px; border: none; background: rgba(0,0,0,0.06); cursor: pointer; font-size: 20px; display: flex; align-items: center; justify-content: center; border-radius: 8px; flex-shrink: 0; }
.bottom-fullscreen-btn { margin-top: auto; }
.tool-btn:hover { background: rgba(0,0,0,0.12); }
.tool-btn.active { background: rgba(24,144,255,0.15); color: #1890ff; }

/* 右侧面板：绝对定位浮动在按钮左侧，垂直居中 */
.right-panel {
  position: absolute;
  right: calc(100% + 12px);
  top: 50%;
  transform: translateY(-50%);
  width: 300px;
  max-width: 70vw;
  max-height: 85vh;
  background: #fff;
  border: 1px solid #e8e8e8;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.12);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  z-index: 30;
}
.right-panel-hd {
  padding: 14px 18px;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 15px;
  font-weight: 600;
  flex-shrink: 0;
}
.close-btn {
  width: 24px; height: 24px;
  border: none; background: #f5f5f5; border-radius: 4px;
  cursor: pointer; font-size: 12px; color: #666;
  display: flex; align-items: center; justify-content: center;
}
.close-btn:hover { background: #eee; }
.right-panel-bd { flex: 1; overflow-y: auto; padding: 16px; min-height: 0; }

/* 过渡动画 */
.panel-slide-enter-active, .panel-slide-leave-active { transition: opacity 0.2s, transform 0.2s; }
.panel-slide-enter-from, .panel-slide-leave-to { opacity: 0; transform: translateY(-50%) translateX(8px); }

/* 右侧面板：绝对定位浮动在按钮左侧，垂直居中 */
.right-panel {
  position: absolute;
  right: calc(100% + 12px);
  top: 50%;
  transform: translateY(-50%);
  width: 300px;
  max-width: 70vw;
  max-height: 85vh;
  background: #fff;
  border: 1px solid #e8e8e8;
  border-radius: 12px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.12);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  z-index: 30;
}
.right-panel-hd {
  padding: 14px 18px;
  border-bottom: 1px solid #f0f0f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 15px;
  font-weight: 600;
  flex-shrink: 0;
}
.close-btn {
  width: 24px; height: 24px;
  border: none; background: #f5f5f5; border-radius: 4px;
  cursor: pointer; font-size: 12px; color: #666;
  display: flex; align-items: center; justify-content: center;
}
.close-btn:hover { background: #eee; }
.right-panel-bd { flex: 1; overflow-y: auto; padding: 16px; min-height: 0; }

/* 过渡动画 */
.panel-slide-enter-active, .panel-slide-leave-active { transition: opacity 0.2s, transform 0.2s; }
.panel-slide-enter-from, .panel-slide-leave-to { opacity: 0; transform: translateY(-50%) translateX(8px); }

/* 书架面板 */
.shelf-panel { min-height: 120px; }
.shelf-grid { display: flex; flex-direction: column; gap: 8px; }
.shelf-card {
  display: flex; flex-direction: row; align-items: center; gap: 12px;
  padding: 10px 12px; border-radius: 8px; border: 1px solid #f0f0f0;
  cursor: pointer; transition: all 0.15s; background: #fafafa;
}
.shelf-card:hover { border-color: #1890ff; background: #f5f9ff; transform: translateX(2px); box-shadow: 0 2px 8px rgba(24,144,255,0.08); }
.shelf-cover {
  width: 36px; height: 36px; border-radius: 6px; background: linear-gradient(135deg, #1890ff, #36cfc9);
  display: flex; align-items: center; justify-content: center; color: #fff; font-size: 16px; font-weight: 600; flex-shrink: 0;
}
.shelf-cover-img {
  width: 36px; height: 50px; border-radius: 6px; overflow: hidden; flex-shrink: 0;
  background: #f0f0f0;
}
.shelf-cover-img img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.shelf-info { text-align: left; width: 100%; overflow: hidden; }
.shelf-name { font-size: 13px; color: #333; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* 设置面板 */
.settings-panel { display: flex; flex-direction: column; gap: 20px; }
.setting-group { display: flex; flex-direction: column; gap: 10px; }
.group-label { font-size: 13px; color: #666; font-weight: 500; }
.size-control { display: flex; align-items: center; gap: 10px; }
.size-control button {
  width: 32px; height: 32px; border: 1px solid #ddd; border-radius: 6px;
  background: #fff; cursor: pointer; font-size: 16px; color: #333;
  display: flex; align-items: center; justify-content: center;
}
.size-control button:hover { border-color: #1890ff; color: #1890ff; }
.size-dots { flex: 1; display: flex; gap: 6px; justify-content: center; }
.dot { width: 12px; height: 12px; border-radius: 3px; background: #e8e8e8; transition: background 0.2s; }
.dot.active { background: #1890ff; }
.weight-grid { display: flex; flex-wrap: wrap; gap: 6px; }
.weight-btn {
  padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px;
  background: #fff; cursor: pointer; font-size: 12px; color: #666;
}
.weight-btn.active { background: #1890ff; color: #fff; border-color: #1890ff; }
.theme-grid { display: flex; flex-wrap: wrap; gap: 6px; }
.theme-btn {
  padding: 8px 14px; border: 1px solid #ddd; border-radius: 6px;
  background: #fff; cursor: pointer; font-size: 13px; color: #666;
}
.theme-btn.active { background: #1890ff; color: #fff; border-color: #1890ff; }
.font-family-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 6px; }
.font-btn {
  padding: 8px 10px; border: 1px solid #ddd; border-radius: 6px;
  background: #fff; cursor: pointer; font-size: 13px; color: #666;
}
.font-btn.active { background: #1890ff; color: #fff; border-color: #1890ff; }

/* 空状态 */
.empty-placeholder { display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 32px 0; color: #bbb; }
.empty-placeholder svg { margin-bottom: 10px; }
.empty-placeholder p { font-size: 13px; margin: 0; }

/* 数据管理 */
.data-management { border-top: 1px solid #f0f0f0; padding-top: 16px; margin-top: 8px; }
.danger-btn {
  width: 100%; padding: 8px; border: 1px solid #ff4d4f; border-radius: 6px;
  background: #fff; cursor: pointer; font-size: 13px; color: #ff4d4f; transition: all 0.15s;
}
.danger-btn:hover { background: #ff4d4f; color: #fff; }

/* 全屏导航 */
.fullnav { position: fixed; left: 50%; bottom: 24px; transform: translateX(-50%); display: flex; align-items: center; gap: 8px; z-index: 100; padding: 6px; background: rgba(0,0,0,0.4); backdrop-filter: blur(10px); border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.3); }
.fullnav .nav-btn { padding: 8px 16px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.4); background: rgba(255,255,255,0.15); color: #fff; cursor: pointer; font-size: 14px; font-weight: 500; box-shadow: 0 4px 12px rgba(0,0,0,0.3); transition: all 0.2s; display: flex; align-items: center; }
.fullnav .nav-btn:hover:not(:disabled) { background: rgba(255,255,255,0.35); transform: translateY(-2px); box-shadow: 0 6px 16px rgba(0,0,0,0.4); border-color: #fff; }
.fullnav .nav-btn:disabled { opacity: 0.5; cursor: not-allowed; }

.full-chapter-wrapper { display: flex; align-items: center; min-width: 60px; justify-content: center; }
.chapter-indicator.full-screen {
  background: transparent;
  border: none;
  box-shadow: none;
  color: #fff;
  font-family: 'Georgia', 'Times New Roman', serif;
  font-size: 15px;
  font-weight: 600;
  padding: 4px 10px;
  cursor: pointer;
  transition: background 0.2s;
  border-radius: 6px;
  letter-spacing: 0.5px;
}
.chapter-indicator.full-screen:hover { background: rgba(255,255,255,0.15); }

.chapter-jump-input-wrapper.full-screen { width: 70px; }
.chapter-input.full-screen {
  width: 100%;
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.4);
  border-radius: 6px;
  padding: 4px 6px;
  font-size: 14px;
  font-family: 'Georgia', serif;
  color: #fff;
  text-align: center;
  outline: none;
}
.chapter-input.full-screen::placeholder { color: rgba(255,255,255,0.5); }

/* 全屏目录按钮 */
.toc-float { position: fixed; left: 12px; top: 50%; transform: translateY(-50%); z-index: 110; padding: 6px 10px; border-radius: 6px; border: none; background: rgba(0,0,0,0.4); color: #fff; cursor: pointer; font-size: 12px; }

/* 全屏目录浮层 */
.full-toc-overlay { position: fixed; inset: 0; z-index: 120; background: rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center; padding: 20px; }
.full-toc { width: 100%; max-width: 360px; max-height: 70vh; background: #fff; border-radius: 10px; display: flex; flex-direction: column; overflow: hidden; }
.full-toc-hd { padding: 10px 14px; border-bottom: 1px solid #eee; display: flex; align-items: center; justify-content: space-between; font-size: 14px; flex-shrink: 0; }
.full-toc-bd { flex: 1; overflow-y: auto; padding: 6px 0; }
.full-toc-item { display: flex; align-items: center; gap: 6px; padding: 8px 12px; cursor: pointer; font-size: 15px; }
.full-toc-item .toc-icon { font-size: 13px; color: #999; flex-shrink: 0; }
.full-toc-item.active { background: rgba(24,144,255,0.1); border-left: 3px solid #1890ff; font-weight: 600; }

/* 主题适配 */
.theme-dark { background: #1a1a1a; color: #e0e0e0; }
.theme-dark .reader-sidebar { background: #2d2d2d; border-color: #444; color: #e0e0e0; }
.theme-dark .sidebar-header { border-color: #444; color: #e0e0e0; }
.theme-dark .right-panel, .theme-dark .full-toc { background: #2d2d2d; border-color: #444; }
.theme-dark .right-panel-hd { border-color: #444; color: #e0e0e0; }
.theme-dark .reader-right { background: #2d2d2d; border-color: #444; }
.theme-dark .close-btn { background: #444; color: #ccc; }
.theme-dark .shelf-card { background: #383838; border-color: #444; }
.theme-dark .shelf-name { color: #e0e0e0; }
.theme-dark .weight-btn, .theme-dark .theme-btn { background: #3a3a3a; border-color: #555; color: #ccc; }
.theme-dark .weight-btn.active, .theme-dark .theme-btn.active { background: #1890ff; color: #fff; border-color: #1890ff; }
.theme-dark .size-control button { background: #3a3a3a; border-color: #555; color: #ccc; }
.theme-dark .dot { background: #555; }
.theme-dark .dot.active { background: #1890ff; }
.theme-dark .font-btn { background: #3a3a3a; border-color: #555; color: #ccc; }
.theme-dark .font-btn.active { background: #1890ff; color: #fff; border-color: #1890ff; }
.theme-dark .danger-btn { background: #3a3a3a; border-color: #ff4d4f; color: #ff4d4f; }
.theme-dark .danger-btn:hover { background: #ff4d4f; color: #fff; }
.theme-dark .nav-btn { background: rgba(255,255,255,0.1); border-color: rgba(255,255,255,0.2); color: #eee; }

.theme-green { background: #e8f0e3; color: #3a5a3a; }
.theme-green .reader-toolbar { background: #e8f0e3; border-color: #d4e8c8; }
.theme-green .reader-sidebar { background: #e8f0e3; border-color: #d4e8c8; }
.theme-green .sidebar-header { border-color: #d4e8c8; }
.theme-green .reader-right { background: #e8f0e3; border-color: #d4e8c8; }
.theme-green .right-panel, .theme-green .full-toc { background: #e8f0e3; border-color: #d4e8c8; }
.theme-green .shelf-card { background: #f0f7eb; border-color: #d4e8c8; }
.theme-green .weight-btn, .theme-green .theme-btn { background: #f0f7eb; border-color: #c8dba0; }
.theme-green .weight-btn.active, .theme-green .theme-btn.active { background: #5a9e42; color: #fff; border-color: #5a9e42; }
.theme-green .size-control button { background: #f0f7eb; border-color: #c8dba0; }
.theme-green .font-btn { background: #f0f7eb; border-color: #c8dba0; }
.theme-green .font-btn.active { background: #5a9e42; color: #fff; border-color: #5a9e42; }
.theme-green .resize-bar:hover { background: rgba(46,74,46,0.1); }
.theme-green .nav-btn { background: #fff; color: #3a5a3a; border-color: #c8e0c0; box-shadow: 0 2px 8px rgba(0,0,0,0.05); font-weight: 600; }
.theme-green .nav-btn:hover:not(:disabled) { background: #f4f9f0; color: #1e3a1e; border-color: #a8c8a0; }
.theme-green .chapter-indicator { background: #fff; color: #3a5a3a; border-color: #c8e0c0; font-weight: 600; }
.theme-green .chapter-input { border-color: #c8e0c0; color: #1e3a1e; box-shadow: 0 2px 6px rgba(58,90,58,0.15); }
.theme-green .fullscreen-btn-float { background: #fff; color: #3a5a3a; border-color: #c8e0c0; }
.theme-green .fullscreen-btn-float:hover { background: #f4f9f0; color: #1e3a1e; }

.theme-dark .reader-main { background: #1a1a1a; color: #d0d0d0; }
.theme-green .reader-main { background: #e8f0e3; color: #3a3a3a; }
</style>