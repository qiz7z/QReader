<template>
  <div class="library-view">
    <header class="library-header">
      <h1>我的书架</h1>
      <SearchBar v-model="searchQuery" @update:modelValue="handleSearch" />
    </header>
    <main class="library-content">
      <UploadButton @book-imported="handleBookImported" />
      <p v-if="isLoading" class="loading-text">加载中...</p>
      <div v-else-if="filteredBooks.length === 0 && !isLoading" class="empty-library">
        <p>书架是空的，点击上方"导入书籍"开始阅读</p>
      </div>
      <BookGrid
        v-else
        :books="filteredBooks"
        @book-click="handleBookClick"
        @book-delete="handleBookDelete"
      />
    </main>
  </div>
</template>

<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useLibraryStore } from '@/stores/library'
import UploadButton from '@/components/UploadButton.vue'
import BookGrid from '@/components/BookGrid.vue'
import SearchBar from '@/components/SearchBar.vue'
import type { BookRecord } from '@/types'

const router = useRouter()
const libraryStore = useLibraryStore()

const filteredBooks = computed(() => libraryStore.filteredBooks)
const isLoading = computed(() => libraryStore.isLoading)
const searchQuery = computed({
  get: () => libraryStore.searchQuery,
  set: (val: string) => libraryStore.setSearchQuery(val),
})

const handleBookImported = (book: BookRecord) => {
  libraryStore.addBook(book)
}

const handleBookClick = (bookId: string) => {
  router.push({ name: 'reader', params: { id: bookId } })
}

const handleBookDelete = (bookId: string) => {
  libraryStore.removeBook(bookId)
}

const handleSearch = (query: string) => {
  libraryStore.setSearchQuery(query)
}

onMounted(() => {
  libraryStore.loadBooks()
})
</script>

<style scoped>
.library-view {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.library-header {
  display: flex;
  flex-wrap: wrap;
  gap: 15px;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  padding-bottom: 20px;
  border-bottom: 1px solid #eee;
}

.library-header h1 {
  margin: 0;
  font-size: 24px;
  color: #333;
}

.library-content {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.loading-text {
  text-align: center;
  color: #999;
  padding: 40px;
}

.empty-library {
  text-align: center;
  padding: 60px 20px;
  color: #999;
  font-size: 16px;
}

@media (max-width: 600px) {
  .library-header {
    flex-direction: column;
    align-items: stretch;
  }
  .search-bar {
    width: 100%;
  }
}
</style>
