export interface ParsedBook {
  id: string
  title: string
  author: string
  cover: ArrayBuffer | null
  content: Chapter[]
  toc: TOCEntry[]
  metadata: Record<string, string>
}

export interface Chapter {
  id: string
  title: string
  content: string
}

export interface TOCEntry {
  title: string
  chapterId: string
  position: number
}

export interface BookRecord {
  id: string
  title: string
  author: string
  format: string
  fileSize: number
  cover: ArrayBuffer | null
  rawFile: ArrayBuffer
  createdAt: number
  updatedAt: number
}

export interface BookmarkRecord {
  id: string
  bookId: string
  chapterId: string
  position: number
  title: string
  createdAt: number
}

export interface NoteRecord {
  id: string
  bookId: string
  chapterId: string
  position: number
  selectedText: string
  note: string
  highlightColor: string
  createdAt: number
  updatedAt: number
}

export interface ProgressRecord {
  bookId: string
  chapterId: string
  position: number
  percentage: number
  updatedAt: number
}

export interface ReaderSettings {
  fontSize: number
  theme: 'light' | 'dark' | 'green'
  fontFamily: string
  lineHeight: number
  margin: number
  fontWeight: number
}

export interface SettingsRecord extends ReaderSettings {
  key: string
}
